import 'package:cosme/widget/big_text.dart';
import 'package:flutter/material.dart';

import '../widget/app_icon.dart';
import '../widget/small_text.dart';

class Catogries extends StatefulWidget {
  const Catogries({Key? key}) : super(key: key);

  @override
  State<Catogries> createState() => _CatogriesState();
}

class _CatogriesState extends State<Catogries> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 70),
            child: Column(
              children: [
                BigText(text: 'Catogries', size: 24, color: Colors.black),
                SizedBox(
                  height: 40,
                ),
                Container(
                  padding: EdgeInsets.only(left: 40),
                  margin: EdgeInsets.only(left: 20),
                  width: 300,
                  height: 50,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      color: Colors.grey[100]),
                  child: Row(
                    // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SizedBox(
                        width: 10,
                      ),
                      AppIcon(icon: Icons.search),
                      SizedBox(
                        width: 20,
                      ),
                      SmallText(
                        text: 'Search Product',
                        color: Colors.grey[400],
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 40,
                ),
                Container(
                  padding: EdgeInsets.only(left: 40),
                  margin: EdgeInsets.only(left: 20),
                  width: 300,
                  height: 50,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      color: Colors.grey[100]),
                  child: Row(
                    // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SizedBox(
                        width: 10,
                      ),
                      AppIcon(icon: Icons.abc),
                      SizedBox(
                        width: 20,
                      ),
                      SmallText(
                        text: 'Search Product',
                        color: Colors.grey[400],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
