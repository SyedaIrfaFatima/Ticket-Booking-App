import 'dart:ui';

class AppColor {
  static final Color textColor = const Color(0XFFccc7c5);
  static final Color mainColor = const Color(0XFFEC7D7F);
}
//   static TextStyle textStyle =
//   TextStyle(fontSize: 16, fontWeight: FontWeight.w500);
// }
