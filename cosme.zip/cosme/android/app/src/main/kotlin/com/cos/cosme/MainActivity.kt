package com.cos.cosme

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
